<?php get_header(); ?>

   <div id="content">
   <div  class="container">
   <div class="row">
        <div id="main" class="clearfix col-xs-12" role="main">

          <?php woocommerce_content(); ?>
      
        </div> <!-- /main -->
        </div><!--/row-->

      </div><!-- /container-->    
      </div> <!-- /content -->


<?php get_footer(); ?>
