           (function($){   //Declare jQuery NameSpace

            // add list class to Woo products
            $( 'ul.products' ).addClass( 'list' );


            })(jQuery); //Close jQuery