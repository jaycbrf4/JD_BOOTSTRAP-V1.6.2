<?php

/**
**
***
***
      WooCommerce customizations
***
***
**
**/


/*
*
 ADD WOO Support
*
*/

add_action( 'after_setup_theme', 'woocommerce_support' );
  function woocommerce_support() {
      add_theme_support( 'woocommerce' );
  }

//Change the default output for the Woo Content
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'my_theme_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'my_theme_wrapper_end', 10);

  function my_theme_wrapper_start() {
    echo '<section class="clearfix">';
  }

  function my_theme_wrapper_end() {
    echo '</section>';
  }


// add content after the shop loop
add_action( 'woocommerce_after_shop_loop', 'jd_bootstrap_after_shop', 10 );

  function jd_bootstrap_after_shop(){
    echo '<div class="after-shop" style="color:#fff;background: #f00;padding:4px;margin:8px 0;">This is after the shop loop content coming from the functions file</div><!-- /.after-shop -->';
  };



// Override theme default specification for product # per row
function loop_columns() {
return 1; // 1 products per row
}
add_filter('loop_shop_columns', 'loop_columns', 999);



//Override the default number of products per page 1000 is a high number so will show all if less that 1000
add_filter( 'loop_shop_per_page', 'new_loop_shop_per_page', 20 );
  function new_loop_shop_per_page( $cols ) {
    // $cols contains the current number of products per page based on the value stored on Options -> Reading
    // Return the number of products you wanna show per page.
    $cols = 1000;
    return $cols;
  }



// remove default sorting dropdown
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
// remove default product numbering
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );



/**
 * @snippet       Add Stock Quantity on Shop Page
 * @how-to        Watch tutorial @ https://businessbloomer.com/?p=19055
 * @sourcecode    https://businessbloomer.com/?p=19849
 * @author        Rodolfo Melogli
 * @testedwith    WooCommerce 2.5.2
 */
 
// Add Stock Quantity on Shop Page
function show_stock() {
  global $product;
  if ( $product->stock ) { // if manage stock is enabled 
    if ( number_format($product->stock,0,'','') < 6 ) { // if stock is low
    echo '<div class="stock-wrapper"><div class="stock-info label label-danger">Only ' . number_format($product->stock,0,'','') . ' in stock!</div></div><!-- /.stock-wrapper -->';
    } else {
    echo '<div class="stock-wrapper"><div class="stock-info label label-success">' . number_format($product->stock,0,'','') . ' in stock</div></div><!-- /.stock-wrapper -->'; 
    }
  }
}
 
add_action('woocommerce_after_shop_loop_item','show_stock', 7);


add_action('woocommerce_shop_loop_item_title', 'jd_bootstrap_we_deliver_this_item');
  function jd_bootstrap_we_deliver_this_item() {
    echo '<div class="deliver-item"><span class="label label-primary">We Deliver This Item</span></div><!-- /.deliver-item -->';
  };


/**
 * @snippet       WooCommerce  Show Product Custom Field in the Category Pages
 * @how-to        Watch tutorial @ https://businessbloomer.com/?p=19055
 * @sourcecode    https://businessbloomer.com/?p=17451
 * @author        Rodolfo Melogli
 * @compatible    WooCommerce 2.4.7
 */
 
// Add custom field to shop loop
add_action( 'woocommerce_after_shop_loop_item_title', 'ins_woocommerce_product_excerpt', 35, 2);  
 
if (!function_exists('ins_woocommerce_product_excerpt'))
{
  function ins_woocommerce_product_excerpt() {
    global $post;
    if ( is_home() || is_shop() || is_product_category() || is_product_tag() ) {
      echo '<span class="excerpt">';
      echo get_post_meta( $post->ID, 'shipping', true );
      echo '</span>';
    }
  }
}


// List view
add_action( 'wp' , 'setup_gridlist' , 20);

      // Setup
      function setup_gridlist() {
        if ( is_shop() || is_product_category() || is_product_tag() || is_product_taxonomy() ) {
          add_action( 'woocommerce_after_shop_loop_item', array( $this, 'gridlist_buttonwrap_open' ), 9);
          add_action( 'woocommerce_after_shop_loop_item', array( $this, 'gridlist_buttonwrap_close' ), 11);
          add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_single_excerpt', 5);
          add_action( 'woocommerce_after_subcategory', array( $this, 'gridlist_cat_desc' ) );
        }
      }

    // Button wrap
      function gridlist_buttonwrap_open() {
        echo apply_filters( 'gridlist_button_wrap_start', '<div class="gridlist-buttonwrap">' );
      }
      function gridlist_buttonwrap_close() {
        echo apply_filters( 'gridlist_button_wrap_end', '</div>' );
      }

    function gridlist_cat_desc( $category ) {
        global $woocommerce;
        echo apply_filters( 'gridlist_cat_desc_wrap_start', '<div itemprop="description">' );
          echo $category->description;
        echo apply_filters( 'gridlist_cat_desc_wrap_end', '</div>' );

      }
