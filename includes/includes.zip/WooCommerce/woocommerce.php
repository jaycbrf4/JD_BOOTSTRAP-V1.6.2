<?php get_header(); ?>

   <div id="content">
     <div  class="container">
     <div class="row">
         <div id="main" class="clearfix" role="main">
          <div class="col-sm-12">
            <div class="woo-content">
              <?php woocommerce_content(); ?>
            </div><!-- /.woo-content -->
          </div><!-- /.col-sm-6 -->
          
        </div> <!-- /main -->
      </div><!--/row-->

        </div><!-- /container-->    
      </div> <!-- /content -->


<?php get_footer(); ?>
