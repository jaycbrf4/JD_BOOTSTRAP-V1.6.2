/** 
* remove WordPress css file for audio element
*
*/

function remove_mediaelement_styles() {
    wp_dequeue_style('wp-mediaelement');
    wp_deregister_style('wp-mediaelement');
}
add_action( 'wp_print_styles', 'remove_mediaelement_styles' );

// add your own custom ccs file to reskin the audio player
function add_audio_player_styles () {
    wp_enqueue_style('jd_bootstrap-audio-player', get_stylesheet_directory_uri() . '/library/css/audio/styles.css', array(), null );
}
add_action( 'wp_enqueue_scripts', 'add_audio_player_styles');