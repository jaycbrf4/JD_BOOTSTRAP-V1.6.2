<?php 



/**
 * Remove the native playlist template and load our custom template
 * @link http://wordpress.stackexchange.com/q/141767/26350
 */

add_action( 'wp_playlist_scripts', 'JD_BOOSTRAP_playlist' );

function JD_BOOSTRAP_playlist()
{
    remove_action( 'wp_footer', 'wp_underscore_playlist_templates', 0 );
    add_action( 'wp_footer', 'JD_BOOTSTRAP_wp_underscore_playlist_templates', 0 );
}

/**
 * Our custom playlist template.
 */

function JD_BOOTSTRAP_wp_underscore_playlist_templates() {
?>
<script type="text/html" id="tmpl-wp-playlist-current-item">
        <# if ( data.image ) { #>
        <img src="{{ data.thumb.src }}"/>
        <# } #>
        <div class="wp-playlist-caption">
                <span class="wp-playlist-item-meta wp-playlist-item-title">&#8220;{{ data.title }}&#8221;</span>
                <# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span><# } #>
                <# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span><# } #>
        </div>
</script>
<script type="text/html" id="tmpl-wp-playlist-item">
        <div class="wp-playlist-item" style="border-bottom:none;">
                <a class="wp-playlist-caption" href="{{ data.src }}">
                        {{ data.index ? ( data.index + '. ' ) : '' }}
                        <# if ( data.caption ) { #>
                                {{ data.caption }}
                        <# } else { #>
                            <span class="wp-playlist-item-title">&#8220;{{{ data.title }}}&#8221;</span>
                            <# if ( data.artists && data.meta.artist ) { #>
                            <span class="wp-playlist-item-artist"> &mdash; {{ data.meta.artist }}</span>
                            <# } #>
                        <# } #>
                </a>
                <# if ( data.meta.length_formatted ) { #>
                <div class="wp-playlist-item-length">{{ data.meta.length_formatted }}</div>
                <# } #>             
        </div>

       
        <div class="wp-playlist-item-download" style="
        	border-bottom:1px solid #666;
        	margin-bottom:4px;
        	position:relative"
        	>
         <a href="{{ data.src }}" download="{{ data.src }}" class="wp-playlist-item-download-file" style="
           position: absolute;
				   right: 35px;
				   top: -20px;"
					>
					 <i class="fa fa-download"></i>
				</a>
        </div>

</script>
<?php }